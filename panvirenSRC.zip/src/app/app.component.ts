import { Component } from '@angular/core';
import { a2Personal,campusData } from './interfaces/panvirenInterface';
import { myBooks } from './interfaces/panvirenInterface';
import jsondata from '../assets/data/Assignment02.json';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'A2panviren';
  panvirenMydata: a2Personal =jsondata.a2Personal;
  bookdatajson: myBooks[]=jsondata.myBooks;
  campusdatajson: campusData[]=jsondata.campusData;


  

}
