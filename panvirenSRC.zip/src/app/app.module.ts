import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { MaterialModule } from './modules/material-ui.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HeaderPanvirenComponent } from './header-panviren/header-panviren.component';
import { FooterPanvirenComponent } from './footer-panviren/footer-panviren.component';
import { BooksPanvirenComponent } from './books-panviren/books-panviren.component';
import { CampusPanvirenComponent } from './campus-panviren/campus-panviren.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderPanvirenComponent,
    FooterPanvirenComponent,
    BooksPanvirenComponent,
    CampusPanvirenComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    provideClientHydration(),
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
