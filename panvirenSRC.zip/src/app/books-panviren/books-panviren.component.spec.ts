import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BooksPanvirenComponent } from './books-panviren.component';

describe('BooksPanvirenComponent', () => {
  let component: BooksPanvirenComponent;
  let fixture: ComponentFixture<BooksPanvirenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BooksPanvirenComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BooksPanvirenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
