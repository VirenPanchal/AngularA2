import { Component,Input } from '@angular/core';
import { myBooks } from  '../interfaces/panvirenInterface';
import { campusData } from '../interfaces/panvirenInterface';

@Component({
  selector: 'app-books-panviren',
  templateUrl: './books-panviren.component.html',
  styleUrl: './books-panviren.component.css'
})
export class BooksPanvirenComponent {
  @Input()myBooks991664038!:myBooks[];
  @Input()campusData991664038!:campusData[];


}
