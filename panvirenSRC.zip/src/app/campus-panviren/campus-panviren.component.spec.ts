import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CampusPanvirenComponent } from './campus-panviren.component';

describe('CampusPanvirenComponent', () => {
  let component: CampusPanvirenComponent;
  let fixture: ComponentFixture<CampusPanvirenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CampusPanvirenComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CampusPanvirenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
