import { Component,Input } from '@angular/core';
import { myBooks } from  '../interfaces/panvirenInterface';
import { campusData } from '../interfaces/panvirenInterface';

@Component({
  selector: 'app-campus-panviren',
  templateUrl: './campus-panviren.component.html',
  styleUrl: './campus-panviren.component.css'
})
export class CampusPanvirenComponent {
  @Input()myBooks991664038!:myBooks[];
  @Input()campusData991664038!:campusData[];

  campus!:string;
  selectedSCampus!:campusData[];
 
  selectedCampus(val:string){
    this.selectedSCampus=[];

    this.campusData991664038.forEach(e=>{
      if(e.campus === val){
        this.selectedSCampus.push(e);
      }
    });
  }

  

}
function e(value: campusData, index: number, array: campusData[]): void {
  throw new Error('Function not implemented.');
}

