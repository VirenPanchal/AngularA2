import { Component,Input } from '@angular/core';
import { a2Personal } from '../interfaces/panvirenInterface';
import { NgStyle } from '@angular/common';

@Component({
  selector: 'app-footer-panviren',
  templateUrl: './footer-panviren.component.html',
  styleUrl: './footer-panviren.component.css'
})
export class FooterPanvirenComponent {
  @Input()panvirenMydata!:a2Personal ;

}
