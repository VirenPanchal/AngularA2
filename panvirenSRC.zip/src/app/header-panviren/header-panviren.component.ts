import { Component, Input } from '@angular/core';
import { a2Personal } from '../interfaces/panvirenInterface';

@Component({
  selector: 'app-header-panviren',
  templateUrl: './header-panviren.component.html',
  styleUrl: './header-panviren.component.css'
})
export class HeaderPanvirenComponent {
  @Input()panvirenMydata!:a2Personal ;


}
